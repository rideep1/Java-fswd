public class stringTrial {
    public static void main(String[] args) {
        String p1= "NEPTUNE";

        StringBuffer str =new StringBuffer(p1);
        str.reverse();

        System.out.println(str);

        System.out.println("\n\nString Builder Trial");
        StringBuilder sbuilder =new StringBuilder(p1);

        sbuilder.reverse();
        System.out.println(sbuilder);

        sbuilder.append("ABC").append("XYZ").reverse();
        System.out.println(sbuilder);
    }
}
