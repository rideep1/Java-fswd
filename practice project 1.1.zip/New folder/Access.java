
public class Access{
    protected void display(){
            System.out.println("Access modifiers");
        }
        }
        class Back
        {
            protected void display()
            {
                System.out.println("protected from class Back");
            }
        }

        class Chase extends Access
        {
            public static void main(String[] args)
            {
                Chase obj1 = new Chase();
                obj1.display();
                Back obj2 = new Back();
                obj2.display();
            }
        }



