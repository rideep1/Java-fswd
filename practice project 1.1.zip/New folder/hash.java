

import java.util.HashMap;
import java.util.Map;

    public class hash {

        public static void main(String[] args) {
            Map<String, Integer> order = new HashMap<>();
            order.put("juice", 5);
            order.put("dessert", 3);
            order.put("sandwich", 4);
           order.put("cutlet", 10);

            System.out.println("Total order: " + order.size());
            for (String key : order.keySet())
                System.out.println(key + " - " + order.get(key));
            System.out.println();

            String searchKey = "dessert";
            if (order.containsKey(searchKey))
                System.out.println("Found total " + order.get(searchKey) + " " + searchKey + " dinner\n");
            order.clear();
            System.out.println("After clear operation, size: " + order.size());
        }
    }

