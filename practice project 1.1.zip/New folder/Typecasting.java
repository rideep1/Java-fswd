public class Typecasting {
    public static void main(String[] args) {
        byte i = 10;
        int x = i + 5;
        System.out.println("byte converted int -> " + x);
        Short short_num = 15;
        int Y = short_num + 115;
        System.out.println("short converted int -> " + Y);
        int num = 5;
        double Z = num + 15.5;
        System.out.println("int converted double -> " + Z);
        double no = 10.51;
        float A = (float) no;
        System.out.println("double casted to float -> "+A);
        char ch = 'z';
        int B = (int) ch;
        System.out.println("char casted to int -> "+B);
    }
}