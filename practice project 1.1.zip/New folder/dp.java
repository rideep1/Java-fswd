public class dp {
   dp() {
        System.out.println("hi");
    }
    dp(int a) {
        System.out.println(" constructor with integer value: " + a);
    }
    dp(float a) {
        System.out.println(" constructor with float value: " + a);
    }
    dp(int a, int b) {
        System.out.println(" constructor with integer values: " + a + " and " + b);
    }
    dp(int a, float b) {
        System.out.println(" constructor with integer value: " + a + " and float value: " + b);
    }
}
    class sp {
        public static void main(String[] ab) {
            dp a1 = new dp();
            new dp(3);
            new dp(3, 2);
            new dp(3.3f);
            new dp(4, 8.9f);
        }
    }
