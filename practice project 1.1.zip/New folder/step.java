public class step {
    static int add(int x, int y) {

        int sum = x + y;
        return sum;
    }

    public static void main(String[] args) {

        int x = 10;
        int y = 20;
        int z = add(x, y);
        System.out.println(x + " + " + y + " = " + z);

        x = 5;
        y = 4;
        z = add(x, y);
        System.out.println(x + " + " + y + " = " + z);
    }
}
