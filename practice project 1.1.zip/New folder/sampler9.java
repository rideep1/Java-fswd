import java.io.*;
import java.util.regex.*;
    class sampler9 {
        public static void main(String[] args)
        {
            System.out.println(Pattern.matches("\\d+", "1234"));

            System.out.println(Pattern.matches("\\D+", "1234"));

            System.out.println(Pattern.matches("\\D+", "MTR"));

            System.out.println(Pattern.matches("\\S+", "mtr"));
        }
    }

