package demo;
class Node1 {
    int number;
    Node1 next;
}

class Main3 {
    public static Node1 push(Node1 head, int A) {
        Node1 n = new Node1();
        n.number = A;
        n.next = head;
        head = n;
        return head;
    }
    public static Node1 deleteN(Node1 head, int position) {
        Node1 temp = head;
        Node1 prev = head;

        for (int i = 0; i < position; i++) {
            if (i == 0 && position == 1) {
                head = head.next;
            } else {
                if (i == position - 1 && temp != null) {
                    prev.next = temp.next;
                } else {
                    prev = temp;
                    if (prev == null)
                        break;
                    temp = temp.next;
                }
            }
        }
        return head;
    }
    public static void printList(Node1 head) {
        while (head != null) {
            if (head.next == null) {
                System.out.println("[" + head.number + "] [" + head + "]->" + "(null)");
            } else {
                System.out.println("[" + head.number + "] [" + head + "]->" + head.next);
            }
            head = head.next;
        }
        System.out.println();
        System.out.println();
    }

    public static void main(String[] args) {
        Node1 list = new Node1();
        list.next = null;
        list = push(list, 1);
        list = push(list, 2);
        list = push(list, 3);

        printList(list);
        list = deleteN(list, 1);
        printList(list);
    }
}




