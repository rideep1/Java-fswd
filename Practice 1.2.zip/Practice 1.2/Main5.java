package demo;
class Node1{
    int data;
    Node1 next;
    Node1 prev;
    public Node1 (int data){
        this.data= data;
        this.next=null;
        this.prev=null;
    }
}
class DoublyLinkedList{
    Node1 head;
    public void insert(int data){
        Node1 newNode = new Node1(data);
        if(head ==null){
            head=newNode;

        }
    }
    public void traverseForward(){
        Node1 current= head;
        System.out.println("Forward traversal:");
        while(current !=null){
            System.out.print(current.data+"");
            current =current.next;
        }
        System.out.println();
    }
    public void traverseBackward(){
        Node1 current = head;
        while(current.next!=null){
            current=current.prev;
        }
        System.out.println();
    }
}

public class Main5 {
    public static void main(String[] args) {
        DoublyLinkedList dll = new DoublyLinkedList();
        dll.insert(1);
        dll.insert(2);
        dll.insert(3);
        dll.traverseBackward();
        dll.traverseBackward();
    }
}
