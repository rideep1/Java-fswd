package com.ecommerce.tests;

public class StandardTestClass {

}
