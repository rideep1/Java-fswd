package fibo;

public class HibernateUtil {

}
