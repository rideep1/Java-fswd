package fibo;

public class HibernateUtil3 {

}
