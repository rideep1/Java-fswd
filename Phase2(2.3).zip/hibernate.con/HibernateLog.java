package fibo;

public class HibernateLog {

}
