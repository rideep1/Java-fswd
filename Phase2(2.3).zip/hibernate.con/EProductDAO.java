package fibo;

public class EProductDAO {

}
