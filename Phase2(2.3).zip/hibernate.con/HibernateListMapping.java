package fibo;

public class HibernateListMapping {

}
