package fibo;

public class EProductEntity {

}
