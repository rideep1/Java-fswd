package fibo;

public class EProduct2 {

}
