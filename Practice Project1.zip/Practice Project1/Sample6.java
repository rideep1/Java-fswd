import java.io.*;
public class Sample6 {
    public static void print(int a,int b) {
      System.out.println("Addition of Positive integers:"+(a+b));
    }

    public static void main(String[] args) {
        int s1=8;
        int s2=-4;
        if(s1>=0 && s2>=0){
            Sample6.print(s1,s2);
        }
        else
        {
            throw new IllegalStateException("Either one or two numbers are not Positive Integer");

        }
    }
}
