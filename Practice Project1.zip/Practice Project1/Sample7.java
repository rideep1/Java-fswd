public class Sample7 {
    public static void main(String[] args) {
        try{
            int data=99/0;
        }
        catch(Exception e)
        {
            System.out.println("can't divided by zero");
        }
    }
}
