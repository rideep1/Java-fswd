public class Sample4 {
    static void help()
    {
        try{
            throw new NullPointerException("unknown_error");
        }
        catch (NullPointerException e){
            System.out.println("caught inside help().");
            throw e;
        }
    }

    public static void main(String[] args) {
        try{
            help();
        }
        catch(NullPointerException e){
            System.out.println("caught in main error name given below:");
            System.out.println(e);
        }
    }
}
