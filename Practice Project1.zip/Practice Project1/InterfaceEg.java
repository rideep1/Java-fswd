interface Dimond1{
    public static int no=100;
    public default void display(){
        System.out.println("display method of Dimond1");
    }
}
interface Dimond2{
    public static int no=200;
    public default void display(){
        System.out.println("display method of Dimond2");

    }
}
public class InterfaceEg implements Dimond1,Dimond2{
    public void display(){
        Dimond1.super.display();
        Dimond2.super.display();}

    public static void main(String[] args) {
        InterfaceEg obj = new InterfaceEg();
        obj.display();
    }
    }

