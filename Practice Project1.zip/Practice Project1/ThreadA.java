public class ThreadA implements Runnable{
    public void run(){
        System.out.println("now thread is running");
    }
    public static void main(String[] args) {
        Runnable r= new ThreadA();
        Thread t= new Thread(r,"My first thread");
        t.start();
        String str = t.getName();
        System.out.println(str);
    }
}
