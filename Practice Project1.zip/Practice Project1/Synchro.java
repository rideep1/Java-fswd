class Counter
{
    int count;
    public synchronized void increment()
    {
        count++;
    }
}
public class Synchro {
    public static void main(String[] args) throws Exception{
        Counter c = new Counter();
        Thread th1 = new Thread(new Runnable()
        {
            public void run(){
                for(int i=1;i<=50;i++ ){
                    c.increment();
                }
            }
        });
    }
}
