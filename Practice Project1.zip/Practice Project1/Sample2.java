
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

    public class Sample2
    {
        FileWriter fw=null;
        public static void main(String[] args) {
            String filePath = ("example.txt");

            createFile(filePath);

            readFile(filePath);


            updateFile(filePath, "Updated content");


            readFile(filePath);


            deleteFile(filePath);
        }


        public static void createFile(String filePath)
        {
            try {
                FileWriter writer = new FileWriter(filePath);
                writer.write("Hello, World!");
                writer.close();
                System.out.println("File created successfully.");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


        public static void readFile(String filePath)
        {
            try {
                FileReader reader = new FileReader(filePath);
                int character;
                while ((character = reader.read()) != -1) {
                    System.out.print((char) character);
                }
                reader.close();
                System.out.println();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


        public static void updateFile(String filePath, String newContent)
        {
            try {
                FileWriter writer = new FileWriter(filePath);
                writer.write(newContent);
                writer.close();
                System.out.println("File updated successfully.");
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }


        public static void deleteFile(String filePath)
        {
            File file = new File(filePath);
            if (file.delete()) {
                System.out.println("File deleted successfully.");
            } else {
                System.out.println("Failed to delete the file.");
            }
        }

    }





